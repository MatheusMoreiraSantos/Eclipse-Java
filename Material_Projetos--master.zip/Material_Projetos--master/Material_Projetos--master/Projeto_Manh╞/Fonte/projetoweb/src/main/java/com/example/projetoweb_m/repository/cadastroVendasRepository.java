package com.example.projetoweb_m.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.projetoweb_m.model.cadastroVendas;

public interface cadastroVendasRepository extends JpaRepository<cadastroVendas, Integer> {

}
