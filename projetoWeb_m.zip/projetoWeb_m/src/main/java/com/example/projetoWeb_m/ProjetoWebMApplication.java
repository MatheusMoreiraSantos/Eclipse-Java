package com.example.projetoWeb_m;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoWebMApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoWebMApplication.class, args);
	}

}
