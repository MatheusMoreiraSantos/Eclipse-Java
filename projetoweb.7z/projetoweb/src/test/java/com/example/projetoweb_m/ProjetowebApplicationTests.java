package com.example.projetoweb_m;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
