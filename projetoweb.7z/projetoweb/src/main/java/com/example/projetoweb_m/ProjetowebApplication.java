package com.example.projetoweb_m;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetowebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetowebApplication.class, args);
	}

}
